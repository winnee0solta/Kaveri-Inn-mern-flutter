package com.example.kaveri_inn_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
